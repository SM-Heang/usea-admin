<footer class="main-footer">
  <div class="float-right d-none d-sm-block">
    <b>Version</b> 1
  </div>
  <strong>Copyright &copy; 2006-2023 <a href="https://usea.edu.kh">University of South-East Asia</a>.</strong> All rights reserved.
</footer><?php /**PATH E:\SMH\wamp\www\usea-edu.kh\usea-admin\resources\views/components/footer.blade.php ENDPATH**/ ?>