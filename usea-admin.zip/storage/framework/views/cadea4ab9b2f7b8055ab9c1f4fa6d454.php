
<?php $__env->startSection('content'); ?>
     <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Post Articles</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.posts')); ?>">Post Articles</a></li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <h1 class="text-center">USEA Article</h1>
        <table class="table table-striped">
          <tr class="text-center">
            <th>Article_id</th>
            <th>Article_title_en</th>
            <th>Article_title_kh</th>
            <th>Article_description_en</th>
            <th>Article_description_kh</th>
            <th>Categories_id</th>
            <th>Keywords</th>
            <th>Sitemap</th>
            <th>Action</th>
          </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td class="text-center">
            <button href="#" class="btn btn-info">Edit</button> 
            <button href="#" class="btn btn-danger">Delete</button>
          </td>
        </tr>
        </table>
        <a href="<?php echo e(route('admin.posts')); ?>"> Add new post</a>
        </div>
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SMH\wamp\www\usea-admin\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>