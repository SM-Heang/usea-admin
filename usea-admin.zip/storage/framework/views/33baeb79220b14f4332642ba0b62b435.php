
<?php $__env->startSection('content'); ?>
     <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Edit User</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="<?php echo e(route('users.create')); ?>">Edit User</a></li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <form action="<?php echo e(route('users.update', ['id' => $users->id])); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <!-- Username input -->
        <div class="form-outline mb-4">
          <label class="form-label" for="name">Name</label>
          <input type="text" id="name" name="name" class="form-control" value="<?php echo e($users->name); ?>"/>
        </div>
        <div class="form-outline mb-4">
          <label class="form-label" for="email">Email</label>
          <input type="text" id="email" name="email" class="form-control" value="<?php echo e($users->email); ?>"/>
        </div>
        <div class="form-outline mb-4">
          <label class="form-label" for="email-verified">Email Verified At</label>
          <input type="text" id="email-verified" name="email-verified" class="form-control" value="<?php echo e($users->email_verified_at); ?>"/>
        </div>
        <!-- Content input -->
        <div class="form-outline mb-4">
          <label class="form-label" for="password">Password</label>
          <input type="text" id="password" name="password" class="form-control" value="<?php echo e($users->password); ?>" />
        </div>   
        <div class="form-outline mb-4">
          <label class="form-label" for="remember-token">Remember Token</label>
          <input type="text" id="remember-token" name="remember-token" class="form-control"  value="<?php echo e($users->remember_token); ?>"/>
        </div> 
        <div class="form-outline mb-4">
          <label class="form-label" for="created-at">Created At</label>
          <input type="date" id="created-at" name="created-at" class="form-control"  value="<?php echo e($users->created_at); ?>"/>
        </div>
        <div class="form-outline mb-4">
          <label class="form-label" for="updated-at">Updated At</label>
          <input type="date" id="updated-at" name="updated-at" class="form-control" value="<?php echo e($users->updated_at); ?>"/>
        </div>
        <div class="form-group text-right">
          <a href="<?php echo e(route('users.index')); ?>" type="submit" class="btn btn-success">Back</a>
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
        </form>
      </div>
      
      <!-- /.col-->
    </div>
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SMH\wamp\www\usea-admin\resources\views/users/edit.blade.php ENDPATH**/ ?>