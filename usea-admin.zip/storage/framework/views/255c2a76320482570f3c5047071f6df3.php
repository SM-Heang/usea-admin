<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="<?php echo e(route('dashboard')); ?>" class="brand-link">
    <img src="dist/img/usea_logo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light">USEA Admin</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user (optional) -->
    

    <!-- SidebarSearch Form -->
    <div class="form-inline">
      <div class="input-group" data-widget="sidebar-search">
        <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-sidebar">
            <i class="fas fa-search fa-fw"></i>
          </button>
        </div>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="true">
        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->
        <li class="nav-item">
          <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(Request::is('/') ? 'active':''); ?>">
            <i class="fas fa-home nav-icon"></i>
            <p>Dashboard</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php echo e(Request::is('user') ? 'active':''); ?>">
            <i class="far fa-user nav-icon"></i>
            <p>User Management</p>
          </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('index', 'home-article-category', 'home-article-group') ? 'menu-open' :''); ?>">
          <a href="#" class="nav-link <?php echo e(Request::is('index', 'home-article-category', 'home-article-group') ? 'active' :''); ?>">
            <i class="far fa-newspaper nav-icon"></i>
            <p>
              USEA Article
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('articles.index')); ?>" class="nav-link <?php echo e(Request::is('index') ? 'active':''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Article</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('articles.categories.index')); ?>" class="nav-link <?php echo e(Request::is('home-article-category') ? 'active':''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Article Categories</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('articles.group.index')); ?>" class="nav-link <?php echo e(Request::is('home-article-group') ? 'active':''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Article Group</p>
              </a>
            </li>
          </ul>
        </li> 
        <li class="nav-item <?php echo e(Request::is('events', 'events-images') ? 'menu-open' :''); ?>">
          <a href="#" class="nav-link <?php echo e(Request::is('events', 'events-images') ? 'active' :''); ?>">
            <i class="far fa-calendar nav-icon"></i>
            <p>
              USEA Events
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('events.index')); ?>" class="nav-link <?php echo e(Request::is('events') ? 'active':''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Events</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('events.images.index')); ?>" class="nav-link <?php echo e(Request::is('events-images') ? 'active':''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Events Images</p>
              </a>
            </li>
          </ul>
        </li> 
        <li class="nav-item">
          <a href="<?php echo e(route('partnership.index')); ?>" class="nav-link <?php echo e(Request::is('partnership') ? 'active' : ''); ?>">
            <i class="fas fa-handshake nav-icon"></i>
            <p>USEA Partnership</p>
          </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('scholarship', 'scholarship-category', 'scholarship-group') ? 'menu-open' :''); ?>">
          <a href="#" class="nav-link <?php echo e(Request::is('scholarship', 'scholarship-category', 'scholarship-group') ? 'active' :''); ?>">
            <i class="nav-icon fas fa-table"></i>
            <p>
              USEA Scholarship
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('scholarship.index')); ?>" class="nav-link <?php echo e(Request::is('scholarship') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Scholarship</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('scholarship.categories.index')); ?>" class="nav-link <?php echo e(Request::is('scholarship-category') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Scholarship Categories</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('scholarship.group.index')); ?>" class="nav-link <?php echo e(Request::is('scholarship-group') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Scholarship Group</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item <?php echo e(Request::is('study-tour', 'study-tour-image') ? 'menu-open' :''); ?>">
          <a href="#" class="nav-link <?php echo e(Request::is('study-tour', 'study-tour-image') ? 'active' :''); ?>">
            <i class="nav-icon fas fa-bus"></i>
            <p>
              USEA Study Tour
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('study-tour.index')); ?>" class="nav-link <?php echo e(Request::is('study-tour') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Study Tour</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('study-tour.images.index')); ?>" class="nav-link <?php echo e(Request::is('study-tour-image') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Study Tour Images</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="d-flex justify-content-center align-items-center nav-item">
          <?php if(auth()->check()): ?>
          <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button role="button" type="submit" class="btn btn-danger"><i class="fas fa-sign-out-alt nav-icon"></i></button>
          </form>  
          <?php else: ?>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(route('login')); ?>" class="d-flex justify-content-center align-items-center nav-link">
            <button role="button" type="submit" class="btn btn-primary"><i class="fas fa-sign-in-alt nav-icon"></i></button>
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside><?php /**PATH E:\SMH\wamp\www\usea-edu.kh\usea-admin\resources\views/components/sidebar.blade.php ENDPATH**/ ?>