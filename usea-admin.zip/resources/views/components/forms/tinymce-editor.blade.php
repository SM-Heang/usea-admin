<div>
    <!-- Simplicity is the ultimate sophistication. - Leonardo da Vinci -->
    <form method="post">
        <textarea id="myeditorinstance">Hello, World!</textarea>
    </form>
</div>